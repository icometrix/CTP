#!/bin/bash
cd $1;
java -jar Runner.jar stop;
